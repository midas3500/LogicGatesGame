using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuManager : MonoBehaviour
{
   
   public void OnClick()
   {
      int nextScene = SceneManager.GetActiveScene().buildIndex + 1;
      SceneManager.LoadScene(nextScene);
   }
}
