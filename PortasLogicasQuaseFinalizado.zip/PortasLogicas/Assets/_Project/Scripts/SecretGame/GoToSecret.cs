using UnityEngine;
using UnityEngine.SceneManagement;

public class GoToSecret : MonoBehaviour
{
   public void OnClick()
   {
      SceneManager.LoadScene(5);
   }
}
