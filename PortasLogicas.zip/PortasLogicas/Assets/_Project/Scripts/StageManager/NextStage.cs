using UnityEngine;
using UnityEngine.SceneManagement;

public class NextStage : MonoBehaviour
{
    
    [Header("Check Slots")]
    [SerializeField] private Slot _currentGate1;
    [SerializeField] private Slot _currentGate2;
    [SerializeField] private Slot _currentGate3;
    
    
    [Header("CheckIf")]
    [SerializeField] private bool _checkedSlot1;
    [SerializeField] private bool _checkedSlot2;
    [SerializeField] private bool _checkedSlot3;
    
    
    
    
    void Update()
    {
        CheckSlots();
    }


    private void CheckSlots()
    {
        if (_currentGate1 != null && _currentGate2 != null && _currentGate3 != null)
        {
            if (_currentGate1.CurrentGate == "andGate")
            {
                _checkedSlot1 = true;
            }
            if (_currentGate2.CurrentGate == "andGate")
            {
                _checkedSlot2 = true;
            }
            if (_currentGate3.CurrentGate == "orGate")
            {
                _checkedSlot3 = true;
            }
        }

        if (_checkedSlot1 == true && _checkedSlot2 == true && _checkedSlot3 == true)
        {
            int nextScene = SceneManager.GetActiveScene().buildIndex + 1;
            SceneManager.LoadScene(nextScene);
        }
    }
}
