using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class Energy : MonoBehaviour
{
    [SerializeField] private Button _button;
    
    public bool _bit;
    
    void Start()
    {
        _bit = false;
    }

    
    void Update()
    {
        TradeValue();
    }
    
    public void OnClick()
    {
        if (_bit == true)
        {
            _bit = false;
        }
        else
        {
            _bit = true;
        }
    }

    private void TradeValue()
    {
        if (_button != null)
        {
            TextMeshProUGUI myText = _button.GetComponentInChildren<TextMeshProUGUI>();
            
            if (_bit == true)
            {
                myText.text = "1";
            }
            else if (_bit == false)
            {
                myText.text = "0";
            }
        }
    }
}
